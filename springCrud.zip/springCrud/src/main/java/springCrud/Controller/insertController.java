package springCrud.Controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.view.RedirectView;

import springCrud.Dao.productDao;
import springCrud.Model.Product;

@Controller
public class insertController {

	@Autowired
	private productDao pdao;
	
	@RequestMapping(value="/addProducts")
	public String addProducts(Model m) {
		
		m.addAttribute("title","AddProduct");
		return "addProduct";
	}
	
	@RequestMapping(value="/insert",method=RequestMethod.POST)
	public RedirectView insert(@ModelAttribute("product") Product product ,Model model,HttpServletRequest request) {
		
		this.pdao.insert(product);
		RedirectView rv=new RedirectView();
		rv.setUrl(request.getContextPath()+"/");
		return rv;
		
		
	}
	
	@ExceptionHandler(Exception.class)
	public String error(Model model) {
		model.addAttribute("error",Exception.class);
		return "errorPage";
	}
}
