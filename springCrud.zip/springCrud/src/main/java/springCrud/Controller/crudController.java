package springCrud.Controller;

import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.view.RedirectView;

import springCrud.Dao.productDao;
import springCrud.Model.Product;

@Controller
public class crudController {

	@Autowired
	private productDao pdao;
	
	
	@RequestMapping("/check")
	public String check() {
		return "check";
	}
	
	@RequestMapping(value="/addProduct")
	public String addProduct(Model m) {
		
		List<Product> products=pdao.getProduct();
		m.addAttribute("products",products);
		m.addAttribute("title","AddProduct");
		return "viewProduct";
	}
	
	
	@RequestMapping(value="/handle",method=RequestMethod.POST)
	public RedirectView handleProduct(@ModelAttribute ("product") Product product,HttpServletRequest request) {
		
		System.out.println(product);
		pdao.createProduct(product);
		RedirectView redirectView = new RedirectView();
		redirectView.setUrl(request.getContextPath()+"/");
		return redirectView;
	}
	
	@RequestMapping(value="/delete/{id}",method = RequestMethod.GET)
	public RedirectView delete(@PathVariable("id") int id,HttpServletRequest request) {
		this.pdao.deleteProduct(id);
		RedirectView redirectView = new RedirectView();
		redirectView.setUrl(request.getContextPath()+"/");
		return redirectView;

		
	}
	@RequestMapping(value="/update/{id}")
	public String update(@PathVariable("id") int id,Model model) {
		
		Product singleProduct=this.pdao.getSingleProduct(id);
		model.addAttribute("singleProduct",singleProduct);
		
		
		
		return "updatePage";
	}
	
	
}
