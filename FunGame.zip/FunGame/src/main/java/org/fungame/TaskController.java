package org.fungame;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.fungame.Dao.TaskDao;
import org.fungame.Model.TaskAssign;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class TaskController {

	@Autowired
	private TaskDao tdao;
	
	

	@RequestMapping(value="/TaskPage")
    public String Task() {
		
    	return "TaskPage";
    }

	@RequestMapping(value="/task" ,method=RequestMethod.POST)
	public String AssigningTask(@ModelAttribute("taskAssign")TaskAssign taskAssign,Model model,HttpServletRequest request) {
		taskAssign.setAssignDate(new Date());
		this.tdao.assign(taskAssign);
		
		return "assignedSuccessfully";
	}
	@RequestMapping(value="/assignedSuccessfully")
	public String assigned() {
		return "assignedSuccessfully";
	}
	@RequestMapping(value="/viewTask")
	public String update(Model model) {
		
		
		
		
		
		return "viewTask";
	}
	
}
