package org.fungame.Dao;

import java.util.List;

import javax.transaction.Transactional;

import org.fungame.Model.homeModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;



@Component
public class homePageDao {

	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	@Transactional
	public void insertData(homeModel hm) {
		 this.hibernateTemplate.saveOrUpdate(hm);
		
	}
public homeModel getSingleProduct(String Email) {
		
		homeModel product = this.hibernateTemplate.get(homeModel.class, Email);
		return product;
	}

public List<homeModel> getAllDetails() {
	List<homeModel> loadAll = this.hibernateTemplate.loadAll(homeModel.class);
	
	return loadAll;
}

}
