package org.fungame.Dao;



import java.util.List;

import javax.transaction.Transactional;

import org.fungame.Model.TaskAssign;
import org.fungame.Model.signupModel;
import org.hibernate.SQLQuery;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;



@Component
public class signupDao {

	@Autowired
	private HibernateTemplate hibernateTemplate;
	@Autowired
	private SessionFactory factory;
	
	@Transactional
	public void insert(signupModel m) {
		 this.hibernateTemplate.saveOrUpdate(m);
		
	}
	
	public List<signupModel> getDetails(){
		
		
		List<signupModel> loadAll = this.hibernateTemplate.loadAll(signupModel.class);
		return loadAll;
		
	}
public signupModel getSingleProduct(int  id) {
	  
	
	
		
		signupModel m=this.hibernateTemplate.get(signupModel.class, id);
		return m;
	}
public TaskAssign viewTask(int  id) {
	  
	
	
	
	TaskAssign m=this.hibernateTemplate.get(TaskAssign.class, id);
	return m;
}

}
