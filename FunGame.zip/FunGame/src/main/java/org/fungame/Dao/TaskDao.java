package org.fungame.Dao;

import javax.transaction.Transactional;

import org.fungame.Model.TaskAssign;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;

@Component
public class TaskDao {

	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	@Transactional
	public void assign(TaskAssign t) {
		this.hibernateTemplate.save(t);
	}
	
    public TaskAssign viewTask(int Id) {
		
		TaskAssign load = this.hibernateTemplate.load(TaskAssign.class, Id);
		return load;
	}
	
}
