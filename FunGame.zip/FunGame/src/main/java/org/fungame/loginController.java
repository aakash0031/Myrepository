package org.fungame;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.fungame.Dao.TaskDao;
import org.fungame.Dao.homePageDao;
import org.fungame.Dao.signupDao;
import org.fungame.Model.TaskAssign;
import org.fungame.Model.homeModel;
import org.fungame.Model.signupModel;
import org.hibernate.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.view.RedirectView;

@Controller
public class loginController {
 
	@Autowired
	private signupDao sdao;
	
	@Autowired
	private homePageDao hdao;
	
	
	@RequestMapping(value="/login" , method=RequestMethod.GET)
	public String login(@RequestParam("Id")int Id,@RequestParam("Email")String email,@RequestParam("Password")String Password,Model model,HttpServletRequest request) {
		
  
		
		
		
		RedirectView rv=new RedirectView();

		signupModel m=this.sdao.getSingleProduct(Id);
		String Email=m.getEmail();
		String Passwords=m.getPassword();
		String Role=m.getRole();
		int Ids=m.getId();	
		
		
		  if(email.equalsIgnoreCase(Email) && Password.equalsIgnoreCase(Passwords)) {
		  
		  if(Role.equalsIgnoreCase("Organizer")) {
			 
			  List<homeModel> Data = this.hdao.getAllDetails();
			  model.addAttribute("Data", Data);
			  System.out.println(Data);
			  return "AdminHome";
		  }
		  
		 
		 
		  model.addAttribute("email",email);
		  model.addAttribute("Ids",Ids);
		 
		  return "homePage"; 
		  }else {
		  
		   return "errorPage";
		  
		  }
		 
		
		
		
		
		
	}
	
	@RequestMapping(value="/homePage")
	public String homePage() {
		return "homePage";
	}
	@RequestMapping(value="/errorPage")
	public String errorPage() {
		return "errorPage";
	}
}
