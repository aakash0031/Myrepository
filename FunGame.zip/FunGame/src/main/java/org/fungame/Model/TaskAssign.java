package org.fungame.Model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class TaskAssign {

	@Id
	private int Number;
	private String Name;
	private String Task;
	@Temporal(TemporalType.DATE)
	private Date AssignDate;
	@ManyToOne
	private homeModel hmodel;
	public int getNumber() {
		return Number;
	}
	public void setNumber(int number) {
		Number = number;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getTask() {
		return Task;
	}
	public void setTask(String task) {
		Task = task;
	}
	public Date getAssignDate() {
		return AssignDate;
	}
	public void setAssignDate(Date assignDate) {
		AssignDate = assignDate;
	}
	public TaskAssign(int number, String name, String task, Date assignDate) {
		super();
		Number = number;
		Name = name;
		Task = task;
		AssignDate = assignDate;
	}
	public TaskAssign() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "TaskAssign [Number=" + Number + ", Name=" + Name + ", Task=" + Task + ", AssignDate=" + AssignDate
				+ "]";
	}
	
	
}
