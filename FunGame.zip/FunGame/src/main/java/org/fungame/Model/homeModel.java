package org.fungame.Model;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class homeModel {
	@Id
	private int ButtonValue;
	private String Email;
    private String Name;
    @Temporal(TemporalType.DATE)
    private Date updatedDate;
    @OneToMany(fetch = FetchType.EAGER)
    private List<TaskAssign> tassign;
	public int getButtonValue() {
		return ButtonValue;
	}

	public void setButtonValue(int buttonValue) {
		ButtonValue = buttonValue;
	}
   
	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public homeModel(int buttonValue, String email, String name, Date updatedDate) {
		super();
		ButtonValue = buttonValue;
		Email = email;
		Name = name;
		this.updatedDate = updatedDate;
	}

	public homeModel() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "homeModel [ButtonValue=" + ButtonValue + ", Email=" + Email + ", Name=" + Name + ", updatedDate="
				+ updatedDate + "]";
	}

	
	

	
	

}
