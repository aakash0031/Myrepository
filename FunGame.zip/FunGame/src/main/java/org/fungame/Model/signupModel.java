package org.fungame.Model;

import javax.persistence.Entity;

import javax.persistence.Id;

@Entity
public class signupModel {

	@Id
	private int Id;
	private String Email;
	private String Password;
	private String Address;
	private String Address2;
	private String City;
	private String State;
	private String Role;
	private int ZipCode;
	
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getAddress2() {
		return Address2;
	}
	public void setAddress2(String address2) {
		Address2 = address2;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	
	public String getRole() {
		return Role;
	}
	public void setRole(String role) {
		Role = role;
	}
	public int getZipCode() {
		return ZipCode;
	}
	public void setZipCode(int zipCode) {
		ZipCode = zipCode;
	}
	public signupModel(int id, String email, String password, String address, String address2, String city,
			String state, String role, int zipCode) {
		super();
		Id = id;
		Email = email;
		Password = password;
		Address = address;
		Address2 = address2;
		City = city;
		State = state;
		Role = role;
		ZipCode = zipCode;
	}
	public signupModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "signupModel [Id=" + Id + ", Email=" + Email + ", Password=" + Password + ", Address=" + Address
				+ ", Address2=" + Address2 + ", City=" + City + ", State=" + State + ", Role=" + Role + ", ZipCode="
				+ ZipCode + "]";
	}
	
	
	
	
	
}
