package org.fungame;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.fungame.Dao.TaskDao;
import org.fungame.Dao.homePageDao;
import org.fungame.Dao.signupDao;
import org.fungame.Model.TaskAssign;
import org.fungame.Model.homeModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.view.RedirectView;



@Controller
public class homeController {

	@Autowired
	private homePageDao hpd;
	
	
	
	@RequestMapping(value="/homePage" ,method=RequestMethod.POST)
	public RedirectView form(@ModelAttribute("homeModel") homeModel hmodel,Model model,HttpServletRequest request) {
		hmodel.setUpdatedDate(new Date());
		
		this.hpd.insertData(hmodel);
		
		int Button=hmodel.getButtonValue();
		
		
		
		model.addAttribute("Button",Button);
		
		RedirectView rv=new RedirectView();
		rv.setUrl(request.getContextPath()+"/thankPage");
		return rv;
	}
	
	
	@RequestMapping(value="/thankPage")
	public String thank() {
		return "thankPage";
	}
	
}
