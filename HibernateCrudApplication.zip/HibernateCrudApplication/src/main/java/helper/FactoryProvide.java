package helper;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class FactoryProvide {

	
	public static SessionFactory sessionFactory;
	public static SessionFactory getSessionFactory() {
		if(sessionFactory==null) {
			Configuration cfg=new Configuration();
			cfg.configure("noteTaker/hibernate.cfg.xml");
			sessionFactory= cfg.buildSessionFactory();
		}
		return sessionFactory;
	}
	public void closeFactory() {
		if(sessionFactory.isOpen()) {
			sessionFactory.close();
		}
	}
}
