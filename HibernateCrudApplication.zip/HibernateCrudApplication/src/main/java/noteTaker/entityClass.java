package noteTaker;

import java.util.Date;
import java.util.Random;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="NoteTaker")
public class entityClass {

	@Id
	private int Id;
	private String Title;
	private String Content;
	private Date AddedDate;
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getTitle() {
		return Title;
	}
	public void setTitle(String title) {
		Title = title;
	}
	public String getContent() {
		return Content;
	}
	public void setContent(String content) {
		Content = content;
	}
	public Date getAddedDate() {
		return AddedDate;
	}
	public void setAddedDate(Date addedDate) {
		AddedDate = addedDate;
	}
	public entityClass( String title, String content, Date addedDate) {
		super();
		this.Id = new Random().nextInt(10000);
		Title = title;
		Content = content;
		AddedDate = addedDate;
	}
	public entityClass() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "EntityClass [Id=" + Id + ", Title=" + Title + ", Content=" + Content + ", AddedDate=" + AddedDate + "]";
	}
		
}
