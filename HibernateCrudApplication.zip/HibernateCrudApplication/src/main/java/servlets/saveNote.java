package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.hibernate.Session;
import org.hibernate.Transaction;

import helper.FactoryProvide;
import noteTaker.entityClass;

/**
 * Servlet implementation class saveNote
 */
public class saveNote extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	  try {
		  String title=request.getParameter("title");
		  String content=request.getParameter("content");
		  
		  entityClass ent = new entityClass(title,content,new Date());
		  
		  System.out.println(ent.getId()+".."+ent.getTitle()+".."+ent.getContent()+".."+ent.getAddedDate());
		  Session s=FactoryProvide.getSessionFactory().openSession();
		  Transaction tx= s.beginTransaction();
		  s.save(ent);
		  
		  tx.commit();
		  s.close();
		  
		  response.setContentType("text/html");
		  PrintWriter out=response.getWriter();
		  out.println("<h1>Added SuccessFully</h1>");
		  
		  
	  }catch(Exception e) {
		  
	  }
	
	}

}
