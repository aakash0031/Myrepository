package servlets;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.Transaction;

import helper.FactoryProvide;
import noteTaker.entityClass;

/**
 * Servlet implementation class updateServlet
 */

public class updateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public updateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String title=request.getParameter("title");
		String content=request.getParameter("content");
		int Id=Integer.parseInt(request.getParameter("Id"));
		
		Session s=FactoryProvide.getSessionFactory().openSession();
	    Transaction tx=s.beginTransaction();
	    
	   entityClass ec= s.get(entityClass.class, Id);
	   ec.setTitle(title);
	   ec.setContent(content);
	   ec.setAddedDate(new Date());
	   
	   
	    
	    tx.commit();
	    s.close();
	response.sendRedirect("allNotes.jsp");
	    
	    
	}

}
