package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.Transaction;

import helper.FactoryProvide;
import noteTaker.entityClass;

/**
 * Servlet implementation class DeleteServlet
 */
public class DeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public DeleteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id=Integer.parseInt(request.getParameter("Id").trim());
		
		Session s=FactoryProvide.getSessionFactory().openSession();
		Transaction tx=s.beginTransaction();
		entityClass e=(entityClass)s.get(entityClass.class,id);
		
		s.delete(e);
		tx.commit();
		s.close();
		response.sendRedirect("allNotes.jsp");
	}

	

}
